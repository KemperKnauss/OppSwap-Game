﻿using System;
using CommunityToolkit.Mvvm.Input;
using CommunityToolkit.Mvvm.ComponentModel;

namespace OppSwap.ViewModels
{
	public partial class MainPageViewModel: ObservableObject
	{
		public MainPageViewModel()
		{
		}

	}
}

