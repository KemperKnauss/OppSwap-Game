﻿using System;
using CommunityToolkit.Mvvm.Input;
using CommunityToolkit.Mvvm.ComponentModel;

namespace OppSwap.ViewModels
{
	public partial class MainPage2ViewModel: ObservableObject
	{
		public MainPage2ViewModel()
		{
		}

	}
}

